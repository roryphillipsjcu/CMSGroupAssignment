<a href="<?php echo $url; ?>"><?php _e( 'Check for updates', AI1WM_PLUGIN_NAME ); ?></a>
